class dropDownCheckBoxList
{
    constructor() 
    {
        //create and define objects
        this.divCtr = 0;
        this.divIds = [];
        this.dropDownSet = [];
        this.tblId = tag('table','1','',{} );
        this.tr1Id = tag( 'tr', this.tblId, '', {style:'vertical-align: top;'} );
        this.td1Id = tag( 'td', this.tr1Id, '', {} );
        this.td2Id = tag( 'td', this.tr1Id, '', {} );
        this.td3Id = tag( 'td', this.tr1Id, '', {} );
    }

    mapBits()
    {
        console.log( "mapBits: ")
        this.bitmap = 0;
            for(let i in this.list)
            {
                if( document.getElementById( this.checkboxIds[ i ] ).checked )
                {
                    this.bitmap = this.bitmap + (1<<i)
                }
            }
            console.log( "mapBits: " + this.type + ": "+ this.bitmap )
    }

    makeCheckBoxList( pCheckBoxListItems) 
    {
        console.log("makeCheckBoxList:" + pCheckBoxListItems);
        this.divCtr++
        this.divIds[ this.divCtr ] = tag('div', pCheckBoxListItems.parentId, '',
        {
            id:"list"+this.divCtr, 
            class:"dropdown-checkbox-list", 
            tabindex:"100"
        })
        console.log(this.divIds[ this.divCtr ])
        let divId
        pCheckBoxListItems.id = divId = this.divIds[ this.divCtr ]
        console.log(this.divIds[ this.divCtr ], divId)
        tag('span', divId, 'Select '+pCheckBoxListItems.type,{ class:"anchor"} )
        let ulId = tag('ul', divId,'',{ class:'items' })
        let li = []
        let inputsId = [] //used in another file??
        for( let i in pCheckBoxListItems.list )
        {
            li[ i ] = tag( 'li', ulId,'',{})
            pCheckBoxListItems.checkboxIds[ i ] = tag( 'input', li[ i ], '', 
            { 
                type:"checkbox",
                //THIS WORKS: onclick:'console.log("ping");'
                // THIS WORKS: onclick:"dropDownSet[ 'fruit ' ].getValues();"
                //onclick:pCheckBoxListItems.name + ".getValues();"
                onclick: pCheckBoxListItems.name + ".mapBits();"
            })
            tag('label',li[ i ],pCheckBoxListItems.list[ i ],{})
        }
    }

    setDropDown(any)
    {
        console.log("setDropDown" + any)
        if(any === 1)
        {    
            console.log("setDropDown:" + this.td1Id);
            this.dropDownSet[ 'levelList' ] = {
                id:'',
                parentId:this.td1Id,
                type:'levelList',
                name:"dropDownSet[ 'levelList' ]",
                //type:'levelList',//"+this.type+"
                list:[
                    'unknown',
                    'know_what_its_for',
                    'used_and_understood',
                    'used_in_custom_project',
                    'used_frequently',
                    'used_frequently_and_in_depth',
                ],
                checkboxIds:[],
                bitmap:0,
                getValues:function(){
                    this.bitmap = 0;
                    for(let i in this.list){
                        if( document.getElementById( this.checkboxIds[ i ] ).checked ){
                            this.bitmap = this.bitmap + (1<<i)
                        }
                    }
                    console.log( this.type + ": "+ this.bitmap )
                }
            }
            return this.dropDownSet[ 'levelList' ];
        }
        if(any === 2)
        {    
            this.dropDownSet[ 'methodList' ] ={
				id:'',
				parentId:this.td2Id,
				name:"dropDownSet[ 'methodList' ]",
				type:'methodList',
				list:[
					'unused',
					'can_use_via_console',
					'can_use_via_CLI',
					'can_use_via_IaC',
					'can_integrate_with_Tooling',
					'can_configure_via_console',
					'can_configure_via_CLI',
					'can_configure_via_IaC',
					'can_configure_in_multi_regions',	
					'can_extend_with_custom_tools',
				],
				checkboxIds:[],
				bitmap:0,
				getValues:function(){
					this.bitmap = 0;
					for(let i in this.list){
						if( document.getElementById( this.checkboxIds[ i ] ).checked ){
							this.bitmap = this.bitmap + (1<<i)
						}
					}
					console.log( this.type + ": "+ this.bitmap )
				}
			}
        }
        console.log("setDropDown:" + this.td1Id);
        console.log(">>" + typeof this.dropDownSet[ 'levelList' ] + 
        JSON.stringify(this.dropDownSet[ 'levelList' ])) 
    }

    checkList()
    {
        let checkList1 = document.getElementById('list1');
        checkList1.getElementsByClassName('anchor')[0].onclick = function(evt) { 
            if (checkList1.classList.contains('visible'))
                checkList1.classList.remove('visible');
            else
                checkList1.classList.add('visible');
        }

        // let checkList2 = document.getElementById('list2');
        // checkList2.getElementsByClassName('anchor')[0].onclick = function(evt) { 
        //     if (checkList2.classList.contains('visible'))
        //         checkList2.classList.remove('visible');
        //     else
        //         checkList2.classList.add('visible');
        // }
        // console.log("Checklist1" + checkList1.id)
        //console.log("Checklist1 and anchor" + checkList1.getElementsByClassName('anchor')[0])
    }
}